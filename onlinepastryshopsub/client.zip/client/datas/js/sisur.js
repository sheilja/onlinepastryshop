var wheight = $(window).height();
var wwidth = $(window).width();
var signboxheight = $('sign-box').height();
$('.sign-box').css('margin-top', (wheight - signboxheight) / 7 + "px");