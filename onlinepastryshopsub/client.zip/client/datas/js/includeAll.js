/*
****************************************************************************
*  This file Includes all necessary files for CSK Admin in only one line.  *
****************************************************************************
*/
// CSS files
$("head").append('<link href="datas/bootstrap/css/bootstrap.min.css" rel="stylesheet"> <link rel="stylesheet" href="datas/assets/animate.css-master/animate.min.css"> <link rel="stylesheet" type="text/css" href="datas/min/csk.min.css">	<link rel="stylesheet" type="text/css" href="datas/css/media-query.css">');
// Js Files
$("body").append('<script src="datas/bootstrap/js/bootstrap.min.js"></script>'+' <script type="text/javascript" src="datas/assets/metisMenu-master/dist/metisMenu.min.js"></script>' + '    <script type="text/javascript" src="datas/assets/jQuery-slimScroll-1.3.8/jquery.slimscroll.js"></script>    ' + '<script type="text/javascript" src="datas/js/app.js"></script>')
