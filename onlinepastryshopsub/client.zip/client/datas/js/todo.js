$('.todo_list.showactions').click(function () {
	// body...
	$(this).toggleClass('striked');
})