$('.carousel').carousel({
  interval: 6000
})