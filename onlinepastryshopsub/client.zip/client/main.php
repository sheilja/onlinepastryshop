<?php
include_once('header_client.php');
include_once('footer_client.php');
?>