<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	
	<title>Solution for Long Dropdowns</title>
	
	<link rel="stylesheet" href="css/style1.css" type="text/css" media="screen, projection"/>
			
	<script type='text/javascript' src='http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js?ver=1.3.2'></script>
	<script type="text/javascript" language="javascript" src="js/jquery.dropdown.js"></script>
</head>

<body>
	<div id="page-wrap">
	
        <h1>Long Dropdowns</h1>
        
        <p>If your dropdowns are this long, you might wanna take a re-look at your navigational strategy. But, if it makes sense, a 
        technique like this may be beneficial.</p>
        
        <p>PROBLEM: Dropdown menu goes down below the fold when opened, making lower items inaccesible.</p>
        <p>SOLUTION? Make menu scroll up and down as you mouse through it.</p>
	   	   
        <ul class="dropdown">
        	<li><a href="#">Really Tall Menu</a>
        		<ul class="sub_menu">
        			 <li><a href="#">Artificial Turf</a></li>
        			 <li><a href="#">Benches &amp; Bleachers</a></li>
        			 <li><a href="#">Communication Devices</a></li>
        			 <li><a href="#">Dugouts</a></li>
        			 <li><a href="#">Fencing &amp; Windscreen</a></li>
        			 <li><a href="#">Floor Protectors</a></li>
        			 <li><a href="#">Foul Poles</a></li>
        			 <li><a href="#">Netting</a></li>
        			 <li><a href="#">Outdoor Furniture &amp; Storage</a></li>
        			 <li><a href="#">Outdoor Signs</a></li>
        			 <li><a href="#">Padding</a></li>
        			 <li><a href="#">Scoreboards</a></li>
        			 <li><a href="#">Shade Structures</a></li>
        			 <li><a href="#">Artificial Turf</a></li>
        			 <li><a href="#">Benches &amp; Bleachers</a></li>
        			 <li><a href="#">Communication Devices</a></li>
        			 <li><a href="#">Dugouts</a></li>
        			 <li><a href="#">Fencing &amp; Windscreen</a></li>
        			 <li><a href="#">Floor Protectors</a></li>
        			 <li><a href="#">Foul Poles</a></li>
        			 <li><a href="#">Netting</a></li>
        			 <li><a href="#">Outdoor Furniture &amp; Storage</a></li>
        			 <li><a href="#">Outdoor Signs</a></li>
        			 <li><a href="#">Padding</a></li>
        			 <li><a href="#">Scoreboards</a></li>
        			 <li><a href="#">Shade Structures</a></li>
        			 <li><a href="#">Artificial Turf</a></li>
        			 <li><a href="#">Benches &amp; Bleachers</a></li>
        			 <li><a href="#">Communication Devices</a></li>
        			 <li><a href="#">Dugouts</a></li>
        			 <li><a href="#">Fencing &amp; Windscreen</a></li>
        			 <li><a href="#">Floor Protectors</a></li>
        			 <li><a href="#">Foul Poles</a></li>
        			 <li><a href="#">Netting</a></li>
        			 <li><a href="#">Outdoor Furniture &amp; Storage</a></li>
        			 <li><a href="#">Outdoor Signs</a></li>
        			 <li><a href="#">Padding</a></li>
        			 <li><a href="#">Scoreboards</a></li>
        			 <li><a href="#">Shade Structures</a></li>
        		</ul>
        	</li>
        	<li><a href="#">Kinda Tall Menu</a>
        		<ul class="sub_menu">
        			 <li><a href="#">Artificial Turf</a></li>
        			 <li><a href="#">Benches &amp; Bleachers</a></li>
        			 <li><a href="#">Communication Devices</a></li>
        			 <li><a href="#">Dugouts</a></li>
        			 <li><a href="#">Fencing &amp; Windscreen</a></li>
        			 <li><a href="#">Floor Protectors</a></li>
        			 <li><a href="#">Foul Poles</a></li>
        			 <li><a href="#">Netting</a></li>
        			 <li><a href="#">Outdoor Furniture &amp; Storage</a></li>
        			 <li><a href="#">Outdoor Signs</a></li>
        			 <li><a href="#">Padding</a></li>
        			 <li><a href="#">Scoreboards</a></li>
        		</ul>
        	</li>
        	<li><a href="#">Average Menu</a>
        		<ul class="sub_menu">
        			 <li><a href="#">Artificial Turf</a></li>
        			 <li><a href="#">Benches &amp; Bleachers</a></li>
        			 <li><a href="#">Communication Devices</a></li>
        			 <li><a href="#">Dugouts</a></li>
        			 <li><a href="#">Fencing &amp; Windscreen</a></li>
        		</ul>
        	</li>
        	<li><a href="#">No Menu</a>
        	</li>
        </ul>
		
	</div>
	


</body>

</html>
