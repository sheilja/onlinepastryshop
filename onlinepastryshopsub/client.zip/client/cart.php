<?php
include_once('header_client.php'); 
 if(isset($_POST['btnQ']))
	                     {
						  
						  
						  $ra=$_POST['qty_select']*$_POST['weight_select']*$_POST['hidden_price'];
						   $update_order_details_q="update order_details set qty='".$_POST['qty_select']."',rate='".$ra."',weight='".$_POST['weight_select']."',flavour_id='".$_POST['flavour_select']."' where order_detail_id='".$_POST['oid']."'";
						   $update_order_details=mysql_query($update_order_details_q,$con);
	                       echo $_POST['weight_select'];?><br><?php
	                       echo $_POST['qty_select'];?><br><?php
                           echo $_POST['oid'];?><br><?php
						   
						   
						   
						  // $delete_order_details_q="delete from order_details where order_detail_id='".$_POST['oid']."'";
						   //$delete_order_details=mysql_query($delete_order_details_q,$con);
                       //    echo $_POST['flavour_select'];?><br><?php						   
		   
	                     }
						 if(isset($_POST['btnD']))
						 {
							 $delete_order_details_q="delete from order_details where order_detail_id='".$_POST['oid']."'";
						     $delete_order_details=mysql_query($delete_order_details_q,$con);
                      
						 }
			   
  
?>
<section class="banner_area">
  <div class="container">
    <div class="banner_text">
      <h3>Contact Us</h3>
      <ul>
        <li><a href="index.html">Home</a></li>
        <li><a href="single-blog.html">Contact Us</a></li>
      </ul>
    </div>
  </div>
</section>
<section class="cart_table_area p_100">
        	<div class="container">
				<div class="table-responsive">
					<table class="table">
						<thead>
							<tr>
								<th scope="col">Preview</th>
								<th scope="col">Product</th>
								<th scope="col">Price</th>
								<th scope="col">Flavour</th>
							    <th scope="col">weight</th>
								<th scope="col">Quantity</th>
								
								<th scope="col">Total</th>
								<th scope="col">Action</th>
								<th scope="col"></th>
							</tr>
						</thead>
						<tbody>
						<?php 
						$o_s1=0;
						$fetch_order_master_q="select *from order_master where customer_id='".$_SESSION['login_client']."' and is_order_completed='".$o_s1."'";
						$fetch_order_master=mysql_query($fetch_order_master_q,$con);
						
						$orderid=null;
						$k=null;
						while($fetch_order_master_row=mysql_fetch_array($fetch_order_master))
						{
							$k=1;
							$orderid=$fetch_order_master_row['order_id'];
						}
						$fetch_order_details_q="select *from order_details where order_id='".$orderid."'";
						$fetch_order_details=mysql_query($fetch_order_details_q,$con);
						
						$whilesubtotal=0;
						$whilegsttotal=0;
						?>
						<form action="" method="post"><?php
						while($fetch_order_details_row=mysql_fetch_array($fetch_order_details))
						{
                                    
							         $fetch_order_product_q="select * from product_tbl where product_id='".$fetch_order_details_row['product_id']."'";
                                     $fetch_order_product=mysql_query($fetch_order_product_q,$con);
                                     $fetch_order_product_row=mysql_fetch_array($fetch_order_product);
	                                 ?><input type="hidden" id="gst" value="<?php echo $fetch_order_product_row['gst_slab_id'];?>"><?php									 
							?>
							
							<tr>
							
								<td>

									<img src="../admin/image_product/<?php echo $fetch_order_product_row['product_image'];?>" alt="" height="120px" width="132px">
								</td>
								<td>
								    <?php echo $fetch_order_product_row['product_name'];?>
							    </td>
								<form action="" method="post">
								<td>
								    <?php $price_disp=$fetch_order_product_row['price_per_kg'];
								    echo $price_disp;
								    ?>
								    <input type="hidden" value="<?php echo $price_disp;?>" id="hidden_price" name="hidden_price">
								</td>
								
								<td>
								    
								   	<?php
						            $fetch_flavour="select *from flavour";
						            $row_flavour=mysql_query($fetch_flavour,$con);
                                    $fa=$fetch_order_details_row['flavour_id'];
						            ?>
									<select class="product_select" id="flavour_select" name="flavour_select" style="width: 168px;"><?php
						            while ($rows_flavour=mysql_fetch_array($row_flavour)) 
							        {
						                      ?>	
										      <option value="<?php echo $rows_flavour['flavour_id']; ?>" <?php if($fa==$rows_flavour['flavour_id']){ echo "selected"; } ?>><?php echo $rows_flavour['flavour_name'];?></option>
                                              <?php } ?>
									</select>
                             
								</td>
								    <?php $weight_order=$fetch_order_details_row['weight'];?>
								
							    <td>
								    
								    <?php 
					                $max1=$fetch_order_product_row['max_weight']; 
        						    $min1=$fetch_order_product_row['min_weight'];
        						    ?>
        						    <select class="product_select" id="weight_select" name="weight_select" style="width: 168px;" onchange="change_e(<?php echo $fetch_order_details_row['order_detail_id']?>)">
        						    <?php
								    for ($i=$min1; $i <=$max1 ; $i=$i+1.00) 
								    { 
							        ?>
							    	 <option value="<?php echo $i; ?>" <?php if($weight_order==$i){ echo "selected"; } ?>><?php echo $i."(".$fetch_order_product_row['price_per_kg']*$i.")"; ?></option>
									<?php
                                    }
        						    ?>
                            	    </select>
							    
							       <?php 
							       $p_q="select *from order_master where customer_id='".$_SESSION['login_client']."'";
						           $p=mysql_query($p_q,$con);
					               while($p_row=mysql_fetch_array($p))
						           {
									  ?>
									  <input type="hidden" id="final_total_disp" name="final_total_disp" value="<?php echo $p_row['final_total'];?>">
									  <input type="hidden" id="sub_total_disp" name="sub_total_disp" value="<?php echo $p_row['sub_total'];?>">
									  <input type="hidden" id="GST_total_disp" name="GST_total_disp" value="<?php echo $p_row['GST_total'];?>">
									  <?php
							       }	
							       ?>
								  
								  
								</td>
								<input type="hidden" id="oid" name="oid" value="<?php echo $fetch_order_details_row['order_detail_id'];?>">
								<?php $qty_order=$fetch_order_details_row['qty'];?>
								<td>
									<select class="product_select" id="qty_select" style="width: 168px;" name="qty_select">
										
										<option value="1" <?php if($qty_order=="1"){ echo "selected"; } ?>>1</option>
										<option value="2" <?php if($qty_order=="2"){ echo "selected"; } ?>>2</option>
										<option value="3" <?php if($qty_order=="3"){ echo "selected"; } ?>>3</option> 
										<option value="4" <?php if($qty_order=="4"){ echo "selected"; } ?>>4</option>
										<option value="5" <?php if($qty_order=="5"){ echo "selected"; } ?>>5</option>
									</select>
							
									
								</td>
								

								 
								<td>
								     <?php  $ans_amt=$fetch_order_details_row['rate'];
								     $whilesubtotal=$whilesubtotal+$fetch_order_details_row['rate'];
								     $gst=$fetch_order_details_row['gst_slab_id'];
				                     $gstfetch_q="select *from gst_tbl where gst_slab_id='".$gst."'";
								     $gstfetch=mysql_query($gstfetch_q,$con);
								     if($gstfetch_row=mysql_fetch_array($gstfetch))
								     {
									  $igst=$gstfetch_row['igst'];
								     }
								     $whilegsttotal=$whilegsttotal+($fetch_order_details_row['rate']*$igst)/100;
								     ?>
                                     <div id="t_disp">
								        <?php echo $ans_amt;?>
								     </div>
								</td>
								     <input type="hidden" id="total_order" value="<?php echo $ans_amt;?>">
								<td>
								     <button type="submit" name="btnQ" class="btn" id="<?php echo $fetch_order_details_row['order_detail_id'];?>">Update</button>
								     <button type="submit" name="btnD" class="btn" id="<?php echo $fetch_order_details_row['order_detail_id'];?>">Cancel</button>
								</td>
								</form>
							</tr>
						
			                 			
							<?php
						}
						    $finaltotal=$whilesubtotal+$whilegsttotal;
						    $fetch_order_master_q1="select *from order_master where customer_id='".$_SESSION['login_client']."'";
						    $fetch_order_master1=mysql_query($fetch_order_master_q1,$con);
						
						
						    while($fetch_order_master_row1=mysql_fetch_array($fetch_order_master1))
						    {
							  $orderid=$fetch_order_master_row1['order_id'];
						    }
						    ?>
						    <input type="hidden" id="omi" name="omi" value="<?php echo $orderid;?>">
						    <input type="hidden" id="subtotal1" name="subtotal1" value="<?php echo $whilesubtotal;?>">
						    <input type="hidden" id="gsttotal1" name="gsttotal1" value="<?php echo $whilegsttotal;?>">
						    <input type="hidden" id="finaltotal1" name="finaltotal1" value="<?php echo $finaltotal;?>">						
						</form>
						<?php
                        
						?>
						
							<tr>
								<td>
									<form class="form-inline"> 
										<div class="form-group"> 
											<input type="text" class="form-control" placeholder="Coupon code">
										</div>
										<button type="submit" class="btn">Apply Coupon</button>
									</form>
								</td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								

								<td></td>
								<td>
									
								</td>
							</tr>
						</tbody>
					</table>
				</div>
       			<div class="row cart_total_inner">
        			<div class="col-lg-7"></div>
        			<div class="col-lg-5">
        				<div class="cart_total_text">
        					<div class="cart_head">
        						Cart Total
        					</div>
        					<div class="sub_total">
        						<h5>Sub Total <span>
								<?php 
                                    ?><input type="hidden" id="ss" name="ss" value="<?php echo $whilesubtotal;?>"><?php
							       echo $whilesubtotal;
						          
					 ?></span></h5>
        					</div>
							<?php	$p_q="select *from order_master where customer_id='".$_SESSION['login_client']."'";
						          $p=mysql_query($p_q,$con);
								  ?>
							        					<div class="sub_total">
        						<h5>GST Total <span>
										<?php 

							       echo $whilegsttotal;
						          
					 ?></span></h5>
        					</div>
        					<div class="total">
        						<h4>Total <span>		<?php 
                                   
									  echo $finaltotal;
					              	?>
								   
								  </span></h4>
        					</div>
			            <?php 
	                     if($k!=null)
						 {
						$update_order_master_q="update order_master set sub_total='".$whilesubtotal."',GST_total='".$whilegsttotal."',final_total='".$finaltotal."' where order_id='".$orderid."'";
						$update_order_master=mysql_query($update_order_master_q,$con);
						 }
						?>
        					<div class="cart_footer">
        						<a class="pest_btn" href="ask_pincode.php">Proceed to Checkout</a>
        					</div>
        				</div>
        			</div>
        		</div>
        	</div>
			
        </section>

		
<?php
include_once('footer_client.php');
?>