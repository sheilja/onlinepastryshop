Author: Yogesh singh
Author URL: https://makitweb.com/
Author Email: makitweb@gmail.com
Tutorial Link: https://makitweb.com/set-minimum-maximum-date-in-jquery-ui-datepicker/
