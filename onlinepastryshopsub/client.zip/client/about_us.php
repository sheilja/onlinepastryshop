<?php
include_once('header_client.php');
?>
      <section class="banner_area">
        	<div class="container">
        		<div class="banner_text">
        			<h3>About Us</h3>
        			<ul>
        				<li><a href="#">Home</a></li>
        				<li><a href="#">About Us</a></li>
        			</ul>
        		</div>
        	</div>
        </section>
        <!--================End Main Header Area =================-->
        
        <!--================Our Bakery Area =================-->
        <section class="our_bakery_area p_100">
        	<div class="container">

        			<h2 style="color: #735e33;">Our Bakery Approach </h2>
        			<h6>Pastry Queen is a home made pastry shop in Surat.Pastry Queen aims to serve the most creative and mouth-watering pastries,to help make your celebration even more special!!</h6>
        			<p>Pick a design you like,and then choose from delectable flavors such as the Black Forest,White Forest,Chocolate,Coffee,Fresh Pinaeple,Strawberry,Butterscotch,Mix Fruit and more.You can then sit back and relax,and expert a wonderful pastry to arrive at your desired location,on your chosen date and time.</p>
                     <p>Either call or email us at the information above.</p>
            		<h4 style="color: #735e33;">Specialities</h4>
                    <p>The Black Forest is our customized range of pastries and delicacies for all occasions.</p>
                    <h4 style="color: #735e33;">Regular Pastries</h4>
                    <p>Why wait for an occasion to make it a memorable one? Make memories with our designer everyday pastries. Be it a birthday, an office celebration or just a gift to a loved one, choose Pastry for every happy ocassion.</p>
                    <h4 style="color: #735e33;">Wedding Pastries</h4>
                    <p>A wedding is a once in a lifetime occasion that all family members wait for. With a Pastry Queen Wedding Pastry, ensure that you fascinate your guests in yet another aspect of your wedding celebrations.

                    It brings us immense pleasure to present to you our collection of exclusive Wedding Cakes. Choose from our vast range of designs, or get a completely customized cake, to suit your requirement. You can choose the number of tiers, the color combination, the finishing, or whatever else it may be to create the cake of your dreams.
                    <h4 style="color: #735e33;">3D Pastry</h4>
                    <p>Whether it is the birthday of a child, a teenager or an adult, one of the most awaited parts of a birthday celebration is the cutting of the pastry. Let us make your loved ones birthday pastry memorable.

                    Pastry Queen's 3D pastries are sure to leave you amazed. Available in almost any theme you like, you can choose from our vast range of designs, or provide us with your design. Some of our popular themes are Animal theme, Angry Birds theme, Castle theme, Doll theme , Computer Engineering theme , Mom theme , Makeup-kit theme , Electrical Engineering theme , Baby Shower theme , Doctor theme , Cartoon theme  and many more.

                    </p>
                    <h4 style="color: #735e33;">Luxury Collection</h4>
                    <p>
                    I launched the Luxury Collection of Wedding Cakes at Four Seasons Hotel in September 2013. The idea came about after noticing that most wedding cake designs are made from reference images, which involved little creativity. I wanted introduce designs that were unique, elaborate, different and most importantly, stunning.


                    </p>

                                
        		<div class="row our_bakery_image">
        			<div class="col-md-4 col-6">
        				<img class="img-fluid" src="img/our-bakery/bakery-1.jpg" alt="">
        			</div>
        			<div class="col-md-4 col-6">
        				<img class="img-fluid" src="img/our-bakery/bakery-2.jpg" alt="">
        			</div>
        			<div class="col-md-4 col-6">
        				<img class="img-fluid" src="img/our-bakery/bakery-3.jpg" alt="">
        			</div>
        		</div>
        	</div>
        </section>
        <!--================End Our Bakery Area =================-->
        
        <!--================Bakery Video Area =================-->
        <!--================End Bakery Video Area =================-->
        
        <!--================Our Mission Area =================-->
        <section class="our_mission_area p_100">
        	<div class="container">
        		<div class="row our_mission_inner">
        			<div class="col-lg-3">
        				<div class="single_m_title">
        					<h2>Our Mission</h2>
        				</div>
        			</div>
        			<div class="col-lg-9">
        				<div class="mission_inner_text">
        					<h6>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudan-tium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</h6>
        					<p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatu</p>
        					<ul class="nav">
        						<li><a href="#">Custom cakes</a></li>
        						<li><a href="#">Birthday cakes</a></li>
        						<li><a href="#">Wedding cakes</a></li>
        						<li><a href="#">European delicacies</a></li>
        					</ul>
        				</div>
        			</div>
        		</div>
        	</div>
        </section>
        <!--================End Our Mission Area =================-->
        
        <!--================Client Says Area =================-->
        <section class="client_says_area p_100">
        	<div class="container">
        		<div class="client_says_inner">
        			<div class="c_says_title">
        				<h2>What Our Client Says</h2>
        			</div>
        			<div class="client_says_slider owl-carousel">
        				<div class="item">
        					<div class="media">
        						<div class="d-flex">
        							<img src="img/client/client-1.png" alt="">
        							<h3>“</h3>
        						</div>
        						<div class="media-body">
        							<p>Osed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci sed quia non numquam qui ratione voluptatem sequi nesciunt. Neque porro quisquam est.</p>
        							<h5>- Robert joe</h5>
        						</div>
        					</div>
        				</div>
        				<div class="item">
        					<div class="media">
        						<div class="d-flex">
        							<img src="img/client/client-1.png" alt="">
        						</div>
        						<div class="media-body">
        							<p>Osed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci sed quia non numquam qui ratione voluptatem sequi nesciunt. Neque porro quisquam est.</p>
        							<h5>- Robert joe</h5>
        						</div>
        					</div>
        				</div>
        				<div class="item">
        					<div class="media">
        						<div class="d-flex">
        							<img src="img/client/client-1.png" alt="">
        						</div>
        						<div class="media-body">
        							<p>Osed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci sed quia non numquam qui ratione voluptatem sequi nesciunt. Neque porro quisquam est.</p>
        							<h5>- Robert joe</h5>
        						</div>
        					</div>
        				</div>
        			</div>
        		</div>
        	</div>
        </section>
        <!--================End Client Says Area =================-->
        
        <!--================End Client Says Area =================-->
        <!--================End Client Says Area =================-->
        
        <!--================Newsletter Area =================-->
    <?php
include_once('footer_client.php');
?>