<?php
include_once('header_client.php'); 
	$fetch_d_q="select * from order_not_available_tbl order by date_id desc limit 1";
	$fetch_d=mysql_query($fetch_d_q,$con);
	while($row = mysql_fetch_array($fetch_d))
		{
		$d=$row['date1'];
	
		$date=date("Y-m-d");
		//$date = date('y-m-d');
	

		}?>
		    <head>
        <title>How to Set minimum and maximum date in jQuery UI Datepicker</title>
        <link href='jquery-ui.min.css' rel='stylesheet' type='text/css'>
        <script src='jquery-3.0.0.js' type='text/javascript'></script>
        <script src='jquery-ui.min.js' type='text/javascript'></script>
        
        <script type='text/javascript'>
		function abc()
		{
				var a=document.getElementById('datepicker').value;            
            xmlhttp = new XMLHttpRequest();
            xmlhttp.onreadystatechange = function() 
			{
                 if (this.readyState == 4 && this.status == 200)
					 {
                        document.getElementById("e").innerHTML = this.responseText;
                     }
            };
        xmlhttp.open("GET","date_check.php?q="+a,true);
        xmlhttp.send();
		}
		
		
        $(document).ready(function(){

            $('#datepicker').datepicker({
                dateFormat: "yy-mm-dd",
				maxDate: new Date('<?php echo $d; ?>'),
				minDate: new Date('<?php echo $date; ?>')
				//minDate: new Date('2019-01-5')
                //maxDate: new Date('<?php echo $row?>')
               

            });

        });
        

        </script>
    </head>
		<?php
if(!isset($_SESSION['login_client']))
{

     ?><script>window.location = 'sign_in_client.php';</script><?php
}
$fetch_user_q="select *from user_register where user_id='".$_SESSION['login_client']."'";
$fetch_user=mysql_query($fetch_user_q,$con);
if($fetch_user_row=mysql_fetch_array($fetch_user))
{
	$street_address1=$fetch_user_row['street_address'];
	$app_address1=$fetch_user_row['appartment_details'];
	$fullname=$fetch_user_row['user_full_name'];
	$emailadd=$fetch_user_row['user_email'];
	$phone=$fetch_user_row['user_mobile'];
}
$fetch_ordermaster_q="select *from order_master where customer_id='".$_SESSION['login_client']."'";
$fetch_ordermaster=mysql_query($fetch_ordermaster_q,$con);
if($fetch_ordermaster_row=mysql_fetch_array($fetch_ordermaster))
{
	$orderid=$fetch_ordermaster_row['order_id'];
	$stotal=$fetch_ordermaster_row['sub_total'];
	$gsttotal=$fetch_ordermaster_row['GST_total'];
	$shippingcost=$fetch_ordermaster_row['shipping_cost'];
	$ftotal=$fetch_ordermaster_row['final_total'];
	
}

?>
    <section class="banner_area">
        	<div class="container">
        		<div class="banner_text">
        			<h3>Checkout</h3>
        			<ul>
        				<li><a href="index.html">Home</a></li>
        				<li><a href="product-details.html">Product Details</a></li>
        			</ul>
        		</div>
        	</div>
        </section>
<section class="billing_details_area p_100">
            
            <div class="container">
                
                <div class="row">
                	<div class="col-lg-12">
               	    	<div class="main_title" style="padding-bottom:7px;">
               	    		<h2>Billing Details</h2>
               	    	</div>
						
                		<div class="billing_form_area">
                			<form class="billing_form row" action="" method="post" id="contactForm" novalidate="novalidate">
							    <form method="post" action="">

								
								<div class="form-group col-md-4" style="margin-bottom:2px;">
								    <label for="first">Full Name *<?php if(isset($_POST['placed_order'])){
									
									if(isset($_POST['address']))
									{
									
									$update_user_q="update user_register set user_full_name='".$_POST['full_name']."',user_email='".$_POST['email']."',user_mobile='".$_POST['phone']."',street_address='".$_POST['address']."',appartment_details='".$_POST['address2']."' where user_id='".$_SESSION['login_client']."'";
									$update_user=mysql_query($update_user_q,$con);
									$fetch_order_master_q="select *from order_master where customer_id='".$_SESSION['login_client']."'";
									$fetch_order_master=mysql_query($fetch_order_master_q,$con);
									if($fetch_order_master_row=mysql_fetch_array($fetch_order_master))
									{
										$f_c1=$fetch_order_master_row['final_total'];
									}
									$f_c1=$f_c1+$_POST['pincode_h'];
									$update_order_master_q="update order_master set delivery_date='".$_POST['datepicker']."',shipping_cost='".$_POST['pincode_h']."',final_total='".$f_c1."' where customer_id='".$_SESSION['login_client']."'";
									$update_order_master=mysql_query($update_order_master_q,$con);
									 ?><script>window.location = 'order_summary.php?date=<?php echo $_POST['datepicker'];?>';</script><?php
									}
									else
									{
									    $update_user_q="update user_register set user_full_name='".$_POST['full_name']."',user_email='".$_POST['email']."',user_mobile='".$_POST['phone']."' where user_id='".$_SESSION['login_client']."'";
									    $update_user=mysql_query($update_user_q,$con);	
										$sss1=0;
										$update_order_master_q="update order_master set delivery_date='".$_POST['datepicker']."',shipping_cost='".$sss1."' where customer_id='".$_SESSION['login_client']."'";
									    $update_order_master=mysql_query($update_order_master_q,$con);
									    ?><script>window.location = 'order_summary.php?date=<?php echo $_POST['datepicker'];?>';</script><?php

									}
									} ?></label>
									<input type="text" class="form-control" id="full_name" name="full_name" placeholder="First Name" value="<?php echo $fullname;?>">
								</div>
					            <div class="form-group col-md-4" style="margin-bottom:2px;">
								      <label for="address">Date *</label>
									  <input type='text' id="datepicker" name="datepicker" onchange="abc()" style="width: 369px;" />
								</div> 
								<?php 
								if(isset($_POST['select_pincode']))
								{
								if($_POST['select_pincode']!="local")
								{?>
                                 								<?php 
								$fech_shipping_q="select *from pincode_tbl where pincode_number='".$_POST['select_pincode']."'";
										$fech_shipping=mysql_query($fech_shipping_q,$con);
										if($fech_shipping_row=mysql_fetch_array($fech_shipping))
										{
										    $s_c=$fech_shipping_row['shipping_charge'];	
										}
								$f2=$stotal+$gsttotal+$s_c; ?>			
                                <input type="hidden" id="pincode_h" name="pincode_h" value="<?php echo $s_c;?>">								
								<div class="form-group col-md-4" style="margin-bottom:2px;">
								    <label for="first">Pincode *</label>
									<input type="text" class="form-control" id="pincode" name="pincode" placeholder="Full Name" value="<?php echo $_POST['select_pincode'];?>">
								</div>                                
                                  
								<div class="form-group col-md-6" style="margin-bottom:2px;">
								    <label for="address">Address *</label>
									<input type="text" class="form-control" id="address" name="address" placeholder="Street Address" value="<?php echo $street_address1;?>">
									
								</div>
								<div class="form-group col-md-6" style="margin-bottom:2px;">
								<label for="address" type="hidden">*</label>
								<input type="text" class="form-control" id="address2" name="address2" placeholder="Apartment, Suit unit etc (optional)" value="<?php echo $app_address1;?>">
                                </div>
								<?php }
								}
								?>


        				        <div class="form-group col-md-12" id="e" onchange="abc2()" style="color:red; margin-bottom:2px;">
							      
						        </div> 								
								<div class="form-group col-md-6" style="margin-bottom:2px;">
								    <label for="email">Email Address *</label>
									<input type="email" class="form-control" id="email" name="email" placeholder="Email Address" value="<?php echo $emailadd;?>">
								</div>
								<div class="form-group col-md-6"style="margin-bottom:2px;">
								    <label for="phone">Phone *</label>
									<input type="text" class="form-control" id="phone" name="phone" placeholder="Select an option" value="<?php echo $phone;?>">
								</div>
								<div class="form-group col-md-6"style="margin-bottom:2px;">								
                                <button type="submit" value="submit" class="btn pest_btn" name="placed_order" id="placed_order">Proceed to payment</button>
                                </div>                                
								</form>
							</form>
                		</div>
                	</div>

                </div>
            </div>
		
        </section>
		<?php
include_once('footer_client.php');
?>