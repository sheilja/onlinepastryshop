
<?php

include_once('connection.php');
$a1=$_REQUEST['q'];
$fech_date_q="select *from order_not_available_tbl where date1='".$a1."'";
$fech_date=mysql_query($fech_date_q,$con);

while($fech_date_row=mysql_fetch_array($fech_date))
{
	$max=$fech_date_row['max_weight'];
	$placedorder=$fech_date_row['placed_order'];
	if($placedorder==$max)
	{
		?><div id="e"><?php echo "THIS DILIVERY DATE IS NOT AVAILABLE";?></div><?php
	}

}
?>