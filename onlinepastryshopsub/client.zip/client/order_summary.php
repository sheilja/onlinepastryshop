<?php
include_once('header_client.php'); 
?>
	<?php
if(!isset($_SESSION['login_client']))
{

     ?><script>window.location = 'sign_in_client.php';</script><?php
}
$fetch_user_q="select *from user_register where user_id='".$_SESSION['login_client']."'";
$fetch_user=mysql_query($fetch_user_q,$con);
if($fetch_user_row=mysql_fetch_array($fetch_user))
{
	
	$fullname=$fetch_user_row['user_full_name'];
	$emailadd=$fetch_user_row['user_email'];
	$phone=$fetch_user_row['user_mobile'];
}
$fetch_ordermaster_q="select *from order_master where customer_id='".$_SESSION['login_client']."'";
$fetch_ordermaster=mysql_query($fetch_ordermaster_q,$con);
if($fetch_ordermaster_row=mysql_fetch_array($fetch_ordermaster))
{
	$orderid=$fetch_ordermaster_row['order_id'];
	$stotal=$fetch_ordermaster_row['sub_total'];
	$gsttotal=$fetch_ordermaster_row['GST_total'];
	$shippingcost=$fetch_ordermaster_row['shipping_cost'];
	$ftotal=$fetch_ordermaster_row['final_total'];
	
}

?>
  <section class="banner_area">
        	<div class="container">
        		<div class="banner_text">
        			<h3>Checkout</h3>
        			<ul>
        				<li><a href="index.html">Home</a></li>
        				<li><a href="product-details.html">Product Details</a></li>
        			</ul>
        		</div>
        	</div>
        </section>
<section class="billing_details_area p_100">
            
            <div class="container">
                
                <div class="row">

                	<div class="col-lg-5">
                		<div class="order_box_price">
                			<div class="main_title">
                				<h2>Your Order
								<?php if(isset($_POST['placed_order']))
								{
									$o_s=1;
									$m=1;
									$update_master_q="update order_master set payment_method_id='".$m."',is_order_completed='".$o_s."' where customer_id='".$_SESSION['login_client']."'";
                                     
                                        								  
								   $update_master=mysql_query($update_master_q);
								   if(!$update_master)	
								   {
									   echo "oops".mysql_error();
								   }
									$fetch_weight_q="select *from order_master where customer_id='".$_SESSION['login_client']."'";
									
									$fetch_weight=mysql_query($fetch_weight_q,$con);
									$ww=0;
									while($fetch_weight_row=mysql_fetch_array($fetch_weight))
									{
										$od=$fetch_weight_row['order_id'];
										//$ww=$ww+$fetch_weight_row['weight'];
									}
									$fetch_weight_q2="select *from order_details where order_id='".$od."'";
									$fetch_weight2=mysql_query($fetch_weight_q2,$con);
									$ww=0;
									while($fetch_weight_row2=mysql_fetch_array($fetch_weight2))
									{

										$ww=$ww+($fetch_weight_row2['weight'])*($fetch_weight_row2['qty']);
									}
									$fetch_date_q="select *from order_not_available_tbl where date1='".$_REQUEST['date']."'";
									$fetch_date=mysql_query($fetch_date_q,$con);
									while($fetch_date_row=mysql_fetch_array($fetch_date))
									{
										$p_o=$fetch_date_row['placed_order'];
									}
                                    $p_o=$p_o+$ww;
									$update_limit_q="update order_not_available_tbl set placed_order='".$p_o."' where date1='".$_REQUEST['date']."'";
									 
									$update_limit=mysql_query($update_limit_q,$con);
								}?>
								</h2>
                			</div>
							<div class="payment_list">
								<div class="price_single_cost">
								    
								    <?php 
									$fetch_add_to_cart_q="select *from order_details where order_id='".$orderid."'";
                                    $fetch_add_to_cart=mysql_query($fetch_add_to_cart_q,$con);
									while($fetch_add_to_cart_row=mysql_fetch_array($fetch_add_to_cart))
									{
                                        $p1_q="select *from product_tbl where product_id='".$fetch_add_to_cart_row['product_id']."'";
										$p1=mysql_query($p1_q,$con);
										if($p1_row=mysql_fetch_array($p1))
										{
										?><h5><?php echo $p1_row['product_name'];?><span><?php echo $fetch_add_to_cart_row['rate']; ?></span></h5><?php
										}
									    	
									}
									?>
                                    <h3></h3>

									<h4>Subtotal <span><?php echo $stotal; ?></span></h4>
									<h4>GST total <span><?php echo $gsttotal; ?></span></h4>
									<h4>Shipping Cost <span><?php echo $shippingcost?></span></h4>	
                                    


									<h3>Final Total <span><?php echo $ftotal?></span></h3>
								</div>

							</div>

							 <form action="" method="post">
							 	<input type="hidden" name="email" id="email">
							     <input type="hidden" name="pids" id="pids">
								<button type="submit" value="submit" class="btn pest_btn" name="placed_order" id="<?php echo $orderid;?>">place order</button>
							 </form>
									</div>
							
						</div>
                	</div>
                </div>
            </div>
		
        </section>
		

<?php
include_once('footer_client.php'); 
?>